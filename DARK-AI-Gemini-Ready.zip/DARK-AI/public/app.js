(() => {
  'use strict';

  const $ = (s) => document.querySelector(s);
  const STORE_KEY = 'darkai.v1';
  const MAX_CHATS = 60;
  const CONTEXT_MESSAGES = 30;

  const I18N = {
    ar: {
      newChat: 'محادثة جديدة', history: 'السجل', clearAll: 'مسح الكل', close: 'إغلاق',
      send: 'إرسال', placeholder: 'اكتب رسالتك…', tagline: 'بلا وعظ. بلا مجاملات. اسأل أو احكِ.',
      thinking: 'DARK AI يفكّر…', copy: 'نسخ', copied: 'تم النسخ', noChats: 'لا توجد محادثات بعد.',
      confirmClear: 'مسح كل المحادثات نهائياً؟', confirmDel: 'حذف هذه المحادثة؟',
      untitled: 'محادثة جديدة', netError: 'تعذّر الاتصال بالخادم. تحقق من الإنترنت وأعد المحاولة.',
      persona: { rebel: 'المتمرد', blunt: 'الصريح', storyteller: 'الراوي', drama: 'الدراما النفسية', noir: 'الغامض' },
      suggestions: [
        'اكتب لي مشهداً من قصة خيالية عن الغيرة والخيانة بين بالغين',
        'قل لي رأيك الصريح في فكرة مشروعي، بدون مجاملة',
        'ابدأ قصة نفسية مظلمة بطلها رجل لا يثق بأحد'
      ]
    },
    en: {
      newChat: 'New chat', history: 'History', clearAll: 'Clear all', close: 'Close',
      send: 'Send', placeholder: 'Type your message…', tagline: 'No sermons. No flattery. Ask, or tell a story.',
      thinking: 'DARK AI is thinking…', copy: 'Copy', copied: 'Copied', noChats: 'No chats yet.',
      confirmClear: 'Delete all chats permanently?', confirmDel: 'Delete this chat?',
      untitled: 'New chat', netError: 'Could not reach the server. Check your connection and try again.',
      persona: { rebel: 'Rebel', blunt: 'Blunt', storyteller: 'Storyteller', drama: 'Psych drama', noir: 'Mysterious' },
      suggestions: [
        'Write a scene of fiction about jealousy and betrayal between adults',
        'Give me your honest take on my project idea, no flattery',
        'Start a dark psychological story about a man who trusts no one'
      ]
    }
  };
  const PERSONAS = ['rebel', 'blunt', 'storyteller', 'drama', 'noir'];

  /* ---------- state ---------- */
  let state = loadState();
  let busy = false;

  function defaultState() {
    const lang = (navigator.language || 'ar').toLowerCase().startsWith('ar') ? 'ar' : 'en';
    return { lang, persona: 'rebel', chats: [], currentId: null };
  }
  function loadState() {
    try {
      const raw = localStorage.getItem(STORE_KEY);
      if (raw) {
        const s = JSON.parse(raw);
        if (s && Array.isArray(s.chats)) return Object.assign(defaultState(), s);
      }
    } catch (_) { /* ignore */ }
    return defaultState();
  }
  function save() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(state)); } catch (_) { /* storage full or blocked */ }
  }
  const t = () => I18N[state.lang];
  const currentChat = () => state.chats.find((c) => c.id === state.currentId) || null;
  const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

  /* ---------- elements ---------- */
  const el = {
    side: $('#side'), scrim: $('#scrim'), chatList: $('#chatList'), chat: $('#chat'),
    empty: $('#empty'), msgs: $('#msgs'), input: $('#input'), send: $('#send'),
    personas: $('#personas'), suggest: $('#suggest'), langBtn: $('#langBtn')
  };

  /* ---------- text formatting (escape first, then light markdown) ---------- */
  function escapeHtml(s) {
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function format(text) {
    let h = escapeHtml(text);
    h = h.replace(/\*\*(.+?)\*\*/gs, '<strong>$1</strong>');
    h = h.replace(/(^|[^*])\*(?!\s)([^*\n]+?)\*(?!\*)/g, '$1<em>$2</em>');
    return h.replace(/\n/g, '<br>');
  }

  /* ---------- rendering ---------- */
  function applyLang() {
    const lang = state.lang;
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.querySelectorAll('[data-i18n]').forEach((n) => { n.textContent = t()[n.dataset.i18n]; });
    document.querySelectorAll('[data-i18n-ph]').forEach((n) => { n.placeholder = t()[n.dataset.i18nPh]; });
    document.querySelectorAll('[data-i18n-aria]').forEach((n) => { n.setAttribute('aria-label', t()[n.dataset.i18nAria]); });
    el.langBtn.textContent = lang === 'ar' ? 'English' : 'العربية';
    renderPersonas();
    renderSuggestions();
    renderChatList();
    renderMessages();
  }

  function renderPersonas() {
    el.personas.innerHTML = '';
    PERSONAS.forEach((p) => {
      const b = document.createElement('button');
      b.className = 'chip';
      b.type = 'button';
      b.textContent = t().persona[p];
      b.setAttribute('aria-pressed', String(state.persona === p));
      b.addEventListener('click', () => { state.persona = p; save(); renderPersonas(); });
      el.personas.appendChild(b);
    });
  }

  function renderSuggestions() {
    el.suggest.innerHTML = '';
    t().suggestions.forEach((s) => {
      const b = document.createElement('button');
      b.type = 'button';
      b.textContent = s;
      b.addEventListener('click', () => { el.input.value = s; autosize(); el.input.focus(); });
      el.suggest.appendChild(b);
    });
  }

  function renderChatList() {
    el.chatList.innerHTML = '';
    if (!state.chats.length) {
      const li = document.createElement('li');
      li.className = 'no-chats';
      li.textContent = t().noChats;
      el.chatList.appendChild(li);
      return;
    }
    [...state.chats].sort((a, b) => b.updated - a.updated).forEach((c) => {
      const li = document.createElement('li');
      li.className = 'chat-item' + (c.id === state.currentId ? ' active' : '');
      const open = document.createElement('button');
      open.className = 'chat-open';
      open.type = 'button';
      open.textContent = c.title || t().untitled;
      open.addEventListener('click', () => { state.currentId = c.id; save(); renderChatList(); renderMessages(); closeSide(); });
      const del = document.createElement('button');
      del.className = 'chat-del';
      del.type = 'button';
      del.textContent = '✕';
      del.setAttribute('aria-label', 'Delete');
      del.addEventListener('click', () => {
        if (!confirm(t().confirmDel)) return;
        state.chats = state.chats.filter((x) => x.id !== c.id);
        if (state.currentId === c.id) state.currentId = null;
        save(); renderChatList(); renderMessages();
      });
      li.append(open, del);
      el.chatList.appendChild(li);
    });
  }

  function addMessageNode(role, content, isError) {
    const wrap = document.createElement('div');
    wrap.className = 'msg ' + role + (isError ? ' error' : '');
    const bubble = document.createElement('div');
    bubble.className = 'bubble';
    bubble.innerHTML = format(content);
    wrap.appendChild(bubble);
    if (role === 'model' && !isError) {
      const cp = document.createElement('button');
      cp.className = 'copy';
      cp.type = 'button';
      cp.textContent = t().copy;
      cp.addEventListener('click', async () => {
        await copyText(content);
        cp.textContent = t().copied;
        setTimeout(() => { cp.textContent = t().copy; }, 1400);
      });
      wrap.appendChild(cp);
    }
    el.msgs.appendChild(wrap);
    return wrap;
  }

  function renderMessages() {
    el.msgs.innerHTML = '';
    const c = currentChat();
    const has = c && c.messages.length > 0;
    el.empty.hidden = Boolean(has);
    if (has) c.messages.forEach((m) => addMessageNode(m.role, m.content, m.error));
    scrollDown(false);
  }

  function scrollDown(smooth = true) {
    el.chat.scrollTo({ top: el.chat.scrollHeight, behavior: smooth ? 'smooth' : 'auto' });
  }

  function showTyping() {
    const d = document.createElement('div');
    d.className = 'typing';
    d.id = 'typing';
    d.innerHTML = '<span class="dots"><i></i><i></i><i></i></span><span></span>';
    d.lastChild.textContent = t().thinking;
    el.msgs.appendChild(d);
    scrollDown();
  }
  const hideTyping = () => { const n = $('#typing'); if (n) n.remove(); };

  /* ---------- actions ---------- */
  async function copyText(text) {
    try { await navigator.clipboard.writeText(text); return; } catch (_) { /* fallback */ }
    const ta = document.createElement('textarea');
    ta.value = text; ta.setAttribute('readonly', '');
    ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy'); } catch (_) { /* ignore */ }
    ta.remove();
  }

  function newChat() {
    const c = currentChat();
    if (c && c.messages.length === 0) { closeSide(); el.input.focus(); return; }
    state.currentId = null;
    save(); renderChatList(); renderMessages(); closeSide(); el.input.focus();
  }

  function openSide() { el.side.classList.add('open'); el.scrim.classList.add('show'); }
  function closeSide() { el.side.classList.remove('open'); el.scrim.classList.remove('show'); }

  function autosize() {
    el.input.style.height = 'auto';
    el.input.style.height = Math.min(el.input.scrollHeight, 160) + 'px';
  }

  function setBusy(v) { busy = v; el.send.disabled = v; }

  async function sendMessage() {
    const text = el.input.value.trim();
    if (!text || busy) return;

    let chat = currentChat();
    if (!chat) {
      chat = { id: uid(), title: text.slice(0, 40), messages: [], updated: Date.now() };
      state.chats.unshift(chat);
      state.chats = state.chats.slice(0, MAX_CHATS);
      state.currentId = chat.id;
    }
    chat.messages.push({ role: 'user', content: text });
    chat.updated = Date.now();
    save();

    el.input.value = ''; autosize();
    el.empty.hidden = true;
    addMessageNode('user', text);
    renderChatList();
    showTyping();
    setBusy(true);

    const payload = {
      messages: chat.messages.filter((m) => !m.error).slice(-CONTEXT_MESSAGES).map((m) => ({ role: m.role, content: m.content })),
      persona: state.persona,
      lang: state.lang
    };

    try {
      const res = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      const data = await res.json().catch(() => ({}));
      hideTyping();
      if (!res.ok || !data.reply) {
        const msg = data.message || t().netError;
        chat.messages.push({ role: 'model', content: msg, error: true });
        addMessageNode('model', msg, true);
      } else {
        chat.messages.push({ role: 'model', content: data.reply });
        addMessageNode('model', data.reply);
      }
    } catch (_) {
      hideTyping();
      chat.messages.push({ role: 'model', content: t().netError, error: true });
      addMessageNode('model', t().netError, true);
    } finally {
      chat.updated = Date.now();
      save(); setBusy(false); scrollDown();
    }
  }

  /* ---------- events ---------- */
  el.send.addEventListener('click', sendMessage);
  el.input.addEventListener('input', autosize);
  el.input.addEventListener('keydown', (e) => {
    const desktop = window.matchMedia('(pointer: fine)').matches;
    if (e.key === 'Enter' && !e.shiftKey && desktop && !e.isComposing) { e.preventDefault(); sendMessage(); }
  });
  $('#newChatSide').addEventListener('click', newChat);
  $('#newChatTop').addEventListener('click', newChat);
  $('#openSide').addEventListener('click', openSide);
  $('#closeSide').addEventListener('click', closeSide);
  el.scrim.addEventListener('click', closeSide);
  el.langBtn.addEventListener('click', () => { state.lang = state.lang === 'ar' ? 'en' : 'ar'; save(); applyLang(); });
  $('#clearAll').addEventListener('click', () => {
    if (!state.chats.length || !confirm(t().confirmClear)) return;
    state.chats = []; state.currentId = null; save(); renderChatList(); renderMessages();
  });

  /* ---------- red embers effect ---------- */
  function startEmbers() {
    const canvas = $('#fx');
    const ctx = canvas.getContext('2d');
    if (!ctx || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    let w = 0, h = 0, dpr = 1;
    const COUNT = window.innerWidth < 600 ? 28 : 52;
    const parts = [];
    function resize() {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = canvas.clientWidth; h = canvas.clientHeight;
      canvas.width = w * dpr; canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    function spawn(initial) {
      return { x: Math.random() * w, y: initial ? Math.random() * h : h + 10, r: 0.6 + Math.random() * 2, v: 0.2 + Math.random() * 0.7, drift: (Math.random() - 0.5) * 0.35, a: 0.25 + Math.random() * 0.6, ph: Math.random() * 6.28 };
    }
    resize();
    for (let i = 0; i < COUNT; i++) parts.push(spawn(true));
    window.addEventListener('resize', resize);
    let running = true;
    document.addEventListener('visibilitychange', () => { running = !document.hidden; if (running) requestAnimationFrame(tick); });
    function tick(ts) {
      if (!running) return;
      ctx.clearRect(0, 0, w, h);
      for (let i = 0; i < parts.length; i++) {
        const p = parts[i];
        p.y -= p.v; p.x += p.drift + Math.sin(ts / 900 + p.ph) * 0.25;
        if (p.y < -10) parts[i] = spawn(false);
        const alpha = p.a * Math.min(1, p.y / (h * 0.5));
        ctx.beginPath();
        ctx.fillStyle = 'rgba(255,60,60,' + Math.max(alpha, 0).toFixed(3) + ')';
        ctx.shadowColor = '#e0182d'; ctx.shadowBlur = 10;
        ctx.arc(p.x, p.y, p.r, 0, 6.283);
        ctx.fill();
      }
      requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }

  applyLang();
  startEmbers();
})();
