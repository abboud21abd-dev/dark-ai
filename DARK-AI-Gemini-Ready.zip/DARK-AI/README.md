# DARK AI — Gemini Edition

تطبيق محادثة بواجهة سينمائية سوداء وحمراء، يعمل عبر **Google Gemini API** من الخادم (Node.js + Express).
Cinematic black-and-red chat app powered by the official Gemini `generateContent` API, called only from the backend.

## المزايا / Features
- واجهة عربية RTL وإنجليزية، متوافقة مع هواتف Android، مع مؤثرات حمراء متحركة ومؤشر "يفكّر".
- سجل محادثات (محفوظ في المتصفح)، نسخ الردود، محادثة جديدة، 5 شخصيات بنبرات مختلفة.
- مفتاح Gemini يبقى في الخادم فقط (`GEMINI_API_KEY`)، ولا يظهر في HTML أو JS.
- حفظ سياق المحادثة (آخر 30 رسالة)، وSystem Instructions، ونموذج قابل للتغيير عبر `GEMINI_MODEL`.
- تحقق من المدخلات، حد للطلبات (في الذاكرة)، معالجة أخطاء، ورؤوس أمان أساسية.
- حدود السلامة ثابتة في التعليمات: لا محتوى يخص القاصرين، ولا تصوير للإكراه كأمر مثير، ولا مساعدة في أفعال غير قانونية. كما تبقى فلاتر Gemini الافتراضية فعّالة.

## التشغيل محلياً / Run locally
```bash
npm install
cp .env.example .env      # ثم ضع GEMINI_API_KEY
npm start                 # http://localhost:3000
```
المفتاح من: https://aistudio.google.com/apikey

## متغيرات البيئة / Environment variables
| المتغير | مطلوب | الافتراضي |
|---|---|---|
| `GEMINI_API_KEY` | نعم | — |
| `GEMINI_MODEL` | لا | `gemini-2.5-flash` |
| `PORT` | لا | `3000` (Render يضبطه تلقائياً) |
| `RATE_LIMIT_PER_MIN` | لا | `20` لكل IP |
| `GEMINI_TEMPERATURE` | لا | `1.0` |
| `GEMINI_MAX_OUTPUT_TOKENS` | لا | `2048` |

## النشر على GitHub ثم Render
1. أنشئ مستودعاً على GitHub وارفع المشروع (`.env` مستثنى تلقائياً بواسطة `.gitignore`):
   ```bash
   git init && git add . && git commit -m "DARK AI"
   git branch -M main
   git remote add origin https://github.com/USERNAME/dark-ai.git
   git push -u origin main
   ```
2. في Render: **New → Web Service** → اختر المستودع.
3. الإعدادات: Runtime `Node` — Build Command `npm install` — Start Command `npm start`.
   (أو استخدم **Blueprint** مع الملف `render.yaml` الموجود.)
4. أضف المفتاح: افتح الخدمة → **Environment** → **Add Environment Variable**:
   - Key: `GEMINI_API_KEY`
   - Value: مفتاحك من Google AI Studio
   ثم **Save Changes**، وسيُعاد النشر تلقائياً.
5. اختياري: `GEMINI_MODEL` لتغيير النموذج، و`NODE_VERSION=20`.
6. تحقق: افتح `https://YOUR-APP.onrender.com/api/health` وتأكد أن `geminiConfigured` تساوي `true`.

التطبيق يستمع على `0.0.0.0` ويقرأ `PORT` من البيئة. الخطة المجانية تدخل في سكون بعد فترة خمول، فالطلب الأول قد يتأخر قليلاً.

## API
- `GET /api/health` — حالة الخادم.
- `POST /api/chat` — `{ "messages":[{"role":"user|model","content":"..."}], "persona":"rebel|blunt|storyteller|drama|noir", "lang":"ar|en" }` ← `{ "reply": "..." }`

## الهيكل
```
server.js  package.json  render.yaml  .env.example  .gitignore  README.md
public/index.html  public/style.css  public/app.js
```
