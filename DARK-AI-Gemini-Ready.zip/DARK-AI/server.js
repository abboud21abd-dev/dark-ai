'use strict';
require('dotenv').config();
const express = require('express');
const path = require('path');

const PORT = Number(process.env.PORT) || 3000;
const HOST = '0.0.0.0';
const MODEL = (process.env.GEMINI_MODEL || 'gemini-2.5-flash').trim();
const TEMPERATURE = clamp(Number(process.env.GEMINI_TEMPERATURE) || 1.0, 0, 2);
const MAX_TOKENS = clamp(parseInt(process.env.GEMINI_MAX_OUTPUT_TOKENS, 10) || 2048, 64, 8192);
const RATE_LIMIT = clamp(parseInt(process.env.RATE_LIMIT_PER_MIN, 10) || 20, 1, 600);

const MAX_MESSAGES = 40;
const MAX_MESSAGE_CHARS = 4000;
const MAX_TOTAL_CHARS = 28000;
const GEMINI_TIMEOUT_MS = 55000;

function clamp(n, lo, hi) { return Math.min(hi, Math.max(lo, n)); }

/* ---------------- Personality / system instructions ---------------- */

const BASE_PROMPT = `You are DARK AI: a bold, blunt, rebellious and unconventional AI companion with a cinematic, noir attitude.

VOICE
- Talk directly, like a sharp friend, not a corporate assistant. No moral lectures, no sermons, no boilerplate disclaimers, no "as an AI" filler.
- Be honest and opinionated. Short, punchy sentences when the mood calls for it; rich and atmospheric when writing fiction.
- Mature language and edgy, adult dialogue are fine when they fit the scene or the conversation.
- You can voice multiple characters with distinct tones inside a story. Keep each voice consistent.

WHAT YOU DO WELL
- Adult fiction (all characters are adults, 18+): psychological drama, jealousy, betrayal, obsession, power dynamics and complicated relationships.
- Fictional stories between consenting adults that explore themes such as cuckolding, infidelity and rivalry, focusing on emotion, tension, psychology and dialogue.
- Romantic and sensual scenes are allowed. Handle the most graphic moments with tension, atmosphere and implication rather than pornographic detail.
- Brainstorming, writing, roleplay, debate, advice and everyday questions, answered directly.

HARD LIMITS (always apply, never break character to negotiate them)
- No sexual or romantic content involving anyone under 18, or anyone whose age is unclear or youthful-coded.
- Do not portray sexual violence or non-consent as desirable or arousing.
- No sexual content about real, identifiable people.
- No help with illegal acts, weapons, malware, hacking, fraud, or self-harm. Decline these in one short, direct sentence, without a lecture, and offer a nearby alternative.
- If the user seems to be in real distress or danger, drop the persona and respond with warmth and care.

LANGUAGE
- Reply in the same language the user writes in. If the user writes in Arabic, answer in natural Arabic (Modern Standard with a casual, direct tone) unless they use a dialect. Never mix languages without reason.`;

const PERSONAS = {
  rebel:
    'ACTIVE PERSONA: The Rebel. Defiant, sarcastic, anti-authority. You challenge conventional wisdom and say what others avoid saying, with dry humor and confidence.',
  blunt:
    'ACTIVE PERSONA: The Blunt One. No sugarcoating. Give the straight answer first, then the reasoning. Short, sharp, useful. Zero fluff.',
  storyteller:
    'ACTIVE PERSONA: The Storyteller. A dark, cinematic narrator. Write vivid scenes with atmosphere, strong sensory detail and layered characters. Ask what the user wants next only when it helps the story.',
  drama:
    'ACTIVE PERSONA: Psychological Drama. You focus on inner conflict, jealousy, guilt, desire and betrayal. Explore motives and emotional realism, with tension that builds slowly.',
  noir:
    'ACTIVE PERSONA: The Mysterious One. Low, calm, enigmatic voice. Speak in elegant, minimal lines, with a hint of danger and charm.'
};

function buildSystemInstruction(persona, lang) {
  const langNote = lang === 'ar'
    ? 'The interface language is Arabic (RTL). Default to Arabic.'
    : 'The interface language is English. Default to English.';
  return `${BASE_PROMPT}\n\n${PERSONAS[persona] || PERSONAS.rebel}\n\n${langNote}`;
}

/* ---------------- App ---------------- */

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; script-src 'self'; style-src 'self' https://fonts.googleapis.com; " +
    "font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'"
  );
  next();
});

app.use(express.json({ limit: '128kb' }));

/* simple in-memory rate limiter (per IP, per minute) */
const hits = new Map();
setInterval(() => {
  const now = Date.now();
  for (const [ip, v] of hits) if (now - v.start > 60000) hits.delete(ip);
}, 30000).unref();

function rateLimit(req, res, next) {
  const ip = req.ip || 'unknown';
  const now = Date.now();
  let v = hits.get(ip);
  if (!v || now - v.start > 60000) { v = { start: now, count: 0 }; hits.set(ip, v); }
  v.count += 1;
  if (v.count > RATE_LIMIT) {
    res.setHeader('Retry-After', Math.ceil((60000 - (now - v.start)) / 1000));
    return res.status(429).json({ error: 'rate_limited', message: 'Too many requests. Slow down for a minute.' });
  }
  next();
}

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', model: MODEL, geminiConfigured: Boolean(process.env.GEMINI_API_KEY), uptime: Math.round(process.uptime()) });
});

function validateChatBody(body) {
  if (!body || typeof body !== 'object') return { error: 'Invalid body.' };
  const { messages, persona, lang } = body;
  if (!Array.isArray(messages) || messages.length === 0) return { error: 'messages must be a non-empty array.' };
  if (messages.length > MAX_MESSAGES) return { error: `Too many messages (max ${MAX_MESSAGES}).` };

  const personaKey = Object.prototype.hasOwnProperty.call(PERSONAS, persona) ? persona : 'rebel';
  const langKey = lang === 'en' ? 'en' : 'ar';

  let total = 0;
  const contents = [];
  for (const m of messages) {
    if (!m || typeof m.content !== 'string') return { error: 'Each message needs a string content.' };
    const text = m.content.trim();
    if (!text) continue;
    if (text.length > MAX_MESSAGE_CHARS) return { error: `A message is too long (max ${MAX_MESSAGE_CHARS} characters).` };
    total += text.length;
    const role = m.role === 'user' ? 'user' : (m.role === 'model' || m.role === 'assistant') ? 'model' : null;
    if (!role) return { error: 'Invalid message role.' };
    const last = contents[contents.length - 1];
    if (last && last.role === role) last.parts[0].text += `\n\n${text}`;
    else contents.push({ role, parts: [{ text }] });
  }
  if (total > MAX_TOTAL_CHARS) return { error: 'Conversation is too long. Start a new chat.' };
  while (contents.length && contents[0].role !== 'user') contents.shift();
  if (!contents.length || contents[contents.length - 1].role !== 'user') return { error: 'The last message must come from the user.' };

  return { contents, personaKey, langKey };
}

app.post('/api/chat', rateLimit, async (req, res) => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return res.status(500).json({ error: 'server_misconfigured', message: 'GEMINI_API_KEY is not set on the server.' });

  const v = validateChatBody(req.body);
  if (v.error) return res.status(400).json({ error: 'bad_request', message: v.error });

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(MODEL)}:generateContent`;
  const payload = {
    systemInstruction: { parts: [{ text: buildSystemInstruction(v.personaKey, v.langKey) }] },
    contents: v.contents,
    generationConfig: { temperature: TEMPERATURE, maxOutputTokens: MAX_TOKENS, topP: 0.95 }
  };

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), GEMINI_TIMEOUT_MS);

  try {
    const r = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-goog-api-key': apiKey },
      body: JSON.stringify(payload),
      signal: ctrl.signal
    });
    const data = await r.json().catch(() => ({}));

    if (!r.ok) {
      console.error('Gemini error', r.status, data && data.error && data.error.message);
      if (r.status === 429) return res.status(429).json({ error: 'upstream_rate_limited', message: 'Gemini quota reached. Try again shortly.' });
      if (r.status === 400 || r.status === 403) return res.status(502).json({ error: 'upstream_rejected', message: 'Gemini rejected the request. Check GEMINI_API_KEY and GEMINI_MODEL.' });
      return res.status(502).json({ error: 'upstream_error', message: 'Gemini is unavailable right now.' });
    }

    const cand = data.candidates && data.candidates[0];
    const text = cand && cand.content && Array.isArray(cand.content.parts)
      ? cand.content.parts.map(p => p.text || '').join('').trim()
      : '';

    if (!text) {
      const blocked = (data.promptFeedback && data.promptFeedback.blockReason) || (cand && cand.finishReason === 'SAFETY');
      return res.json({
        reply: blocked
          ? (v.langKey === 'ar' ? 'هذا الطلب تجاوز حدود الأمان. جرّب صياغة أو اتجاهاً آخر.' : 'That one crossed a safety line. Try a different angle.')
          : (v.langKey === 'ar' ? 'لم يصلني رد. أعد المحاولة.' : 'No response came back. Try again.'),
        blocked: Boolean(blocked)
      });
    }
    res.json({ reply: text, model: MODEL });
  } catch (err) {
    const aborted = err && err.name === 'AbortError';
    console.error('Chat error:', aborted ? 'timeout' : err && err.message);
    res.status(aborted ? 504 : 502).json({ error: aborted ? 'timeout' : 'upstream_error', message: aborted ? 'Gemini took too long to answer.' : 'Could not reach Gemini.' });
  } finally {
    clearTimeout(timer);
  }
});

app.use('/api', (req, res) => res.status(404).json({ error: 'not_found' }));
app.use(express.static(path.join(__dirname, 'public'), { maxAge: '1h', extensions: ['html'] }));
app.get('*', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  if (err && err.type === 'entity.too.large') return res.status(413).json({ error: 'too_large', message: 'Request too large.' });
  if (err instanceof SyntaxError) return res.status(400).json({ error: 'bad_json', message: 'Invalid JSON.' });
  console.error(err);
  res.status(500).json({ error: 'server_error', message: 'Unexpected server error.' });
});

if (require.main === module) {
  app.listen(PORT, HOST, () => {
    console.log(`DARK AI listening on http://${HOST}:${PORT} (model: ${MODEL})`);
    if (!process.env.GEMINI_API_KEY) console.warn('WARNING: GEMINI_API_KEY is not set. /api/chat will fail.');
  });
}
module.exports = app;
